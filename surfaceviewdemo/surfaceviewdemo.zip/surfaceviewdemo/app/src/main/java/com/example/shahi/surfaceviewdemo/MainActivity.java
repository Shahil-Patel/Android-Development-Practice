package com.example.shahi.surfaceviewdemo;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.constraint.ConstraintLayout;
import android.support.constraint.ConstraintSet;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    //Code from this program has been used from Beginning Android Games
    //Review SurfaceView, Canvas, continue
    GameSurface gameSurface;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        gameSurface = new GameSurface(this);
        setContentView(gameSurface);
    }
    @Override
    protected void onPause(){
        super.onPause();
        gameSurface.pause();
    }
    @Override
    protected void onResume(){
        super.onResume();
        gameSurface.resume();
    }
    //----------------------------GameSurface Below This Line--------------------------
    public class GameSurface extends SurfaceView implements Runnable,SensorEventListener{
        Thread gameThread;
        SurfaceHolder holder;
        volatile boolean running = false;
        Bitmap ball;
        Bitmap cars;
        Bitmap yellow;
        int ballX=0;
        int carsX=-80;
        int yellowX=-800;
        int x=200;
        int score=-1;
        String sensorOutput="";
        Paint paintProperty;
        int temp=0;
        int screenWidth;
        int screenHeight;
        public GameSurface(Context context) {
            super(context);
            holder=getHolder();
            ball=BitmapFactory.decodeResource(getResources(),R.drawable.ball);
            cars=BitmapFactory.decodeResource(getResources(),R.drawable.cars);
            yellow=BitmapFactory.decodeResource(getResources(),R.drawable.yellow);
            Display screenDisplay = getWindowManager().getDefaultDisplay();
            Point sizeOfScreen = new Point();
            screenDisplay.getSize(sizeOfScreen);
            screenWidth=sizeOfScreen.x;
            screenHeight=sizeOfScreen.y;
            SensorManager sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
            Sensor accelerometerSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            sensorManager.registerListener(this,accelerometerSensor,sensorManager.SENSOR_DELAY_NORMAL);
            paintProperty= new Paint();
            paintProperty.setTextSize(100);
        }
        @Override
        public void run() {
            while (running == true){
                if (holder.getSurface().isValid() == false)
                    continue;
                final Canvas canvas= holder.lockCanvas();
                canvas.drawRGB(0,0,0);
                canvas.drawText(sensorOutput,x,200,paintProperty);
                Paint paintText = new Paint();
                paintText.setColor(Color.WHITE);
                paintText.setStyle(Paint.Style.FILL);
                paintText.setAntiAlias(true);
                paintText.setTextSize(66);
                canvas.drawText("Points: "+String.valueOf(score), screenWidth/2-120, 100, paintText);
                if(carsX>screenHeight||temp==0){
                    carsX=-80;
                    temp=(int)(Math.random()*(screenWidth-30));
                    score++;
                }
                if(yellowX>screenHeight){
                    yellowX=-410;
                }
                canvas.drawBitmap( yellow, screenWidth/2-85,yellowX,null);
                canvas.drawBitmap( ball,(screenWidth/2) - ball.getWidth()/2 +ballX ,(screenHeight/2) - ball.getHeight()/8,null);
                canvas.drawBitmap( cars, temp+50,carsX,null);
                holder.unlockCanvasAndPost(canvas);
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                carsX+=5;
                yellowX+=5;
            }
        }
        public void resume(){
            running=true;
            gameThread=new Thread(this);
            gameThread.start();
        }
        public void pause() {
            running = false;
            while (true) {
                try {
                    gameThread.join();
                } catch (InterruptedException e) {
                }
            }
        }
        @Override
        public void onSensorChanged(SensorEvent event) {
            if(ballX>-285){
                    ballX+=-2*event.values[0];
            }
            else if(ballX<0){
                ballX=-285;
            }
            if(ballX<285){
                ballX+=-2*event.values[0];
            }
            else  if(ballX>0){
                ballX=285;
            }
            Log.d("TAG",ballX+"");
        }
        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {

        }
    }//GameSurface
}//Activity