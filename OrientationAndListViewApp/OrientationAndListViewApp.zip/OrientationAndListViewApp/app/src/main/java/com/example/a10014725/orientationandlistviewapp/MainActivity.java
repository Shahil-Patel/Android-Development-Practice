package com.example.a10014725.orientationandlistviewapp;
import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    ListView list;
    ArrayList<Countries> a;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        list=findViewById(R.id.list);
        final TextView text3=findViewById(R.id.textView3);
        final TextView text4=findViewById(R.id.textView4);
        a=new ArrayList<>();
        a.add(new Countries(86.5,293,R.drawable.sov,"Soviet Union","The Union of Soviet Socialist Republics (USSR), commonly known as the Soviet Union, was a socialist state in Eurasia that existed from 30 December 1922 to 26 December 1991","This empire was actually garbage as everyone went hungary and it collapsed in the 90s (it was creadted in the 20s) 4/10"));
        a.add(new Countries(1.45,126.8,R.drawable.jap,"Japanese Empire","Japan consists of several thousands of islands, of which Honshu, Hokkaido, Kyushu and Shikoku are the four largest. Japan's closest neighbors are Korea, Russia and China","Probably the best empire in the world due to the sheer niceness of its population and because they produce many video games companies like Sony and Nintendo 7/10"));
        a.add(new Countries(.08958,956,R.drawable.dji,"Djibouti","A country located in the Horn of Africa. It is bordered by Eritrea in the north, Ethiopia in the west and south, and Somalia in the southeast. The remainder of the border is formed by the Red Sea and the Gulf of Aden at the east","There is literally nothing special about this country except for tis name 6/10"));
        a.add(new Countries(2.61,120,R.drawable.aus,"Austro-Hungarian Empire","The Austro-Hungarian Empire or the Dual Monarchy in English-language sources, was a constitutional union of the Austrian Empire (the Kingdoms and Lands Represented in the Imperial Council, or Cisleithania) and the Kingdom of Hungary","The absolute coolest empire in the entire world, this empire was a mix of like 5+ ethnicities and held its own against Italy and France during WW1 9/19"));
        a.add(new Countries(92.7,.956,R.drawable.mong,"Mongolian Empire","Originating in the steppes of Central Asia, the Mongol Empire eventually stretched from Eastern Europe and parts of Central Europe to the Sea of Japan, extending northwards into Siberia, eastwards and southwards into the Indian subcontinent, Indochina and the Iranian Plateau",""));
        a.add(new Countries(2.61,53.37,R.drawable.bur,"Burma/Myanmar","The Republic of the Union of Myanmar and also known as Burma, is a country in Southeast Asia. Myanmar is bordered by India and Bangladesh to its west, Thailand and Laos to its east and China to its north and northeast","Biggest empire ever which adds quite a bit of clout to it and there is also Gengis Khan who made the empire super safe and conquered a third of the world. But it broke within a century. 9/10"));
        a.add(new Countries(12.7,1339,R.drawable.india,"India","India’s astounding diversity of religions, languages, and cultures is unique and unparalleled. The society of vast subcontinent, varied and complex in its rich heritage, is among the oldest in the world.","Home country of many in this school, this country is one of the fastest growing countries in the world and has the best colleges and brightest people 8/10"));
        CustomAdapter adapter=new CustomAdapter(this,R.layout.cutom_layout,a);
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                text3.setText("Population (100k): "+a.get(position).getPopulation()+"");
                text4.setText("Land Area (m^3): "+a.get(position).getLandArea()+"");
            }
        });
    }
    public class CustomAdapter extends ArrayAdapter<Countries>
    {
        Context context;
        int resource;
        List<Countries> list;
        public CustomAdapter(@NonNull Context context, int resource, @NonNull List<Countries> objects) {
            super(context, resource, objects);
            this.context=context;
            this.resource=resource;
            this.list=objects;
        }
        @NonNull
        @Override
        public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater inflator=(LayoutInflater)context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
            View adapterLayout=inflator.inflate(resource,null);
            TextView textView=adapterLayout.findViewById(R.id.textView);
            final TextView textView2=adapterLayout.findViewById(R.id.textView2);
            Button button=adapterLayout.findViewById(R.id.button);
            Button button2=adapterLayout.findViewById(R.id.button2);
            ImageView imageView=adapterLayout.findViewById(R.id.imageView);
            textView.setText(a.get(position).getNames());
            if(position==0){
                imageView.setImageResource(a.get(position).getImages());
                textView2.setText(a.get(position).getTexts());
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        textView2.setText(a.get(position).getTextChanged());
                    }
                });
                button2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        a.remove(position);
                        notifyDataSetChanged();
                    }
                });
            }
            if(position==1){
                imageView.setImageResource(a.get(position).getImages());
                textView2.setText(a.get(position).getTexts());
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        textView2.setText(a.get(position).getTextChanged());
                    }
                });
                button2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        a.remove(position);
                        notifyDataSetChanged();
                    }
                });
            }
            if(position==2){
                imageView.setImageResource(a.get(position).getImages());
                textView2.setText(a.get(position).getTexts());
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        textView2.setText(a.get(position).getTextChanged());
                    }
                });
                button2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        a.remove(position);
                        notifyDataSetChanged();
                    }
                });
            }
            if(position==3){
                imageView.setImageResource(a.get(position).getImages());
                textView2.setText(a.get(position).getTexts());
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        textView2.setText(a.get(position).getTextChanged());
                    }
                });
                button2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        a.remove(position);
                        notifyDataSetChanged();
                    }
                });
            }
            if(position==4){
                imageView.setImageResource(a.get(position).getImages());
                textView2.setText(a.get(position).getTexts());
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        textView2.setText(a.get(position).getTextChanged());
                    }
                });
                button2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        a.remove(position);
                        notifyDataSetChanged();
                    }
                });
            }
            if(position==5){
                imageView.setImageResource(a.get(position).getImages());
                textView2.setText(a.get(position).getTexts());
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        textView2.setText(a.get(position).getTextChanged());
                    }
                });
                button2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        a.remove(position);
                        notifyDataSetChanged();
                    }
                });
            }
            if(position==6){
                imageView.setImageResource(a.get(position).getImages());
                textView2.setText(a.get(position).getTexts());
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        textView2.setText(a.get(position).getTextChanged());
                    }
                });
                button2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        a.remove(position);
                        notifyDataSetChanged();
                    }
                });
            }
            return adapterLayout;
        }
    }
    public class Countries{
        double population;
        double landArea;
        int image;
        String name;
        String text;
        String textChanged;
        public Countries(double population, double landArea,int image,String name,String text,String textChanged){
            this.population=population;
            this.landArea=landArea;
            this.image=image;
            this.name=name;
            this.text=text;
            this.textChanged=textChanged;
        }
        public double getPopulation(){
            return population;
        }
        public double getLandArea(){
            return landArea;
        }
        public int getImages(){
            return image;
        }
        public String getNames(){
            return name;
        }
        public String getTexts(){
            return text;
        }
        public String getTextChanged(){
            return textChanged;
        }
    }

}

